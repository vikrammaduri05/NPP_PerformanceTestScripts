﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.VisualStudio.TestTools.WebTesting;
using NPP_PerformanceTests.Core;
using System;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml;

namespace NPP_PerformanceTests.Plugins
{
    public class BasePlugin : WebTestPlugin
    {
        public override void PreRequest(object sender, PreRequestEventArgs e)
        {
            var helperObj = new Helper();
            string WebTestName = e.WebTest.Name;
            string[] TestNameAtr = WebTestName.Split('_');

            //Gets the Transaction URL 
            string URL = helperObj.GetTransactionUrl(TestNameAtr[0]);
            e.Request.Url = URL;            

            //Gets the body data
            string bodydata = helperObj.GetRequestData(TestNameAtr[4], TestNameAtr[2], TestNameAtr[3]);
            var httpBody = e.Request.Body as StringHttpBody;
            
            //Gets the TransactionID and replaces in the bodydata
            //string transid = helperObj.GetTransId(e.WebTest.Context.WebTestUserId.ToString(), e.WebTest.Context.WebTestIteration.ToString());
            string transid = helperObj.GetTransId();
            string pattern = "<TransactionID>(.*?)</TransactionID>";
            Regex rg1 = new Regex(pattern);
            Match m1 = rg1.Match(bodydata);
            if(m1.Success)
            {
                bodydata = Regex.Replace(bodydata, pattern, "<TransactionID>" + transid + "</TransactionID>");
            }

            if (TestNameAtr.Count() > 5)
            {
                string IndTyp = helperObj.GetIndType(TestNameAtr[5]);
                bodydata = Regex.Replace(bodydata, "<IndustryInfo Type=\"(.*?)\">", "<IndustryInfo Type=\"" + IndTyp + " \">");
            }

            Regex rg_or = new Regex("<Origin>");
            Match m1_or = rg_or.Match(bodydata);

            if (m1_or.Success)
            {
                if (TestNameAtr.Count() > 6)
                {
                    string OrField = helperObj.GetOriginField(TestNameAtr[6]);
                    bodydata = Regex.Replace(bodydata, "<Origin>(.*?)</Origin>", " <Origin>" + OrField + "</Origin>");
                }
                else
                {
                    string OrField = helperObj.GetOriginField(TestNameAtr[5]);
                    bodydata = Regex.Replace(bodydata, "<Origin>(.*?)</Origin>", " <Origin>" + OrField + "</Origin>");
                }

            }
            else
            {
                if (TestNameAtr.Count() > 6)
                {
                    string OrField = helperObj.GetOriginField(TestNameAtr[6]);
                    bodydata = Regex.Replace(bodydata, "</UDField1>", "</UDField1><Origin>" + OrField + "</Origin>");
                }
                else
                {
                    string OrField = helperObj.GetOriginField(TestNameAtr[5]);
                    bodydata = Regex.Replace(bodydata, "</UDField1>", "</UDField1><Origin>" + OrField + "</Origin>");
                }
            }

           /* if (TestNameAtr.Count() > 6)
            {
                string OrField = helperObj.GetOriginField(TestNameAtr[6]);
                bodydata = Regex.Replace(bodydata, "</UDField1>", "</UDField1><Origin>" + OrField + "</Origin>");
            }*/

            string Carddata = helperObj.GetCardData(TestNameAtr[1], TestNameAtr[2], TestNameAtr[3]);

            if(Carddata!="" && TestNameAtr[4].ToLower() != "salevoid")
            {
                
                if(TestNameAtr[4].ToLower()=="seek")
                {
                    bodydata = Regex.Replace(bodydata, "<ByCardNum>(.*?)</ByCardNum>", "<ByCardNum>" + Carddata + "</ByCardNum>");
                    
                }
                else
                {
                    bodydata = Regex.Replace(bodydata, "</LaneID>(.*?)</JetPay>", "</LaneID>" + Carddata + "</JetPay>");
                }
                
            }

            if(TestNameAtr[5].ToLower() == "moto" || TestNameAtr[5].ToLower() == "ecom")
            {
                bodydata = Regex.Replace(bodydata, "<CardNum>", "<CardNum CardPresent='false'>");

                if (TestNameAtr.Count() > 6)
                {
                    if (TestNameAtr[6].ToLower() == "mo")
                    {
                        bodydata = Regex.Replace(bodydata, "<IndustryInfo Type=\"(.*?)\">(.*?)</IndustryInfo>", "<IndustryInfo Type=\"MOTO\"></IndustryInfo>");
                    }

                    if (TestNameAtr[6].ToLower() == "to")
                    {
                        bodydata = Regex.Replace(bodydata, "<IndustryInfo Type=\"(.*?)\">(.*?)</IndustryInfo>", "<IndustryInfo Type=\"MOTO\"><PhoneANI>9725038900</PhoneANI><PhoneII>00</PhoneII></IndustryInfo>");
                    }
                }
            }

            if(TestNameAtr[4].ToLower() == "authfinalcapture" || TestNameAtr[4].ToLower() == "authonlycapture" || TestNameAtr[4].ToLower() == "salevoid")
            {

                string LastResStr = e.WebTest.LastResponse.BodyString;
                Regex rg2 = new Regex("<UniqueID>(.*?)</UniqueID>");
                Match m2 = rg2.Match(LastResStr);
                //string UniqueId = e.WebTest.Context["cUniqueId"].ToString(); 
                string UniqueId = m2.Groups[1].Value;
                bodydata = Regex.Replace(bodydata, "<UniqueID>(.*?)</UniqueID>", "<UniqueID>" + UniqueId + "</UniqueID>");
            }
            


            httpBody.BodyString = bodydata;
            
            
        }

        public override void PostRequest(object sender, PostRequestEventArgs e)
        {
            if (e.Response.BodyString.Contains("<ResponseText>APPROVED</ResponseText>") || e.Response.BodyString.Contains("<ActionCode>000</ActionCode>"))
            {
                e.Request.Outcome = Outcome.Pass;
            }
            else
            {
                e.Request.Outcome = Outcome.Fail;
                Regex rg = new Regex("<ActionCode>(.*?)</ActionCode>");
                Match match = rg.Match(e.Response.BodyString);
                if (match.Success)
                {
                    throw new AssertFailedException("Transaction failed with Error Code: " + match.Value);
                }
            }
        }



    }
}
