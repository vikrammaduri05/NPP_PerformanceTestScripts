﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace NPP_PerformanceTests.Core
{
    public class Helper
    {
        private static readonly string StartupPath = Environment.GetEnvironmentVariable("TAF.NCR_Payments_Processing") + @"\NPP_PerformanceTests";
        private string DC1URL = GetNodeValue("TestEnvironmentSettings.xml", "/Environment/DC1URL");
        private string DC2URL = GetNodeValue("TestEnvironmentSettings.xml", "/Environment/DC2URL");


        private static string GetNodeValue(string fileName, string nodeXPath)
        {
            var doc = new XmlDocument();
            doc.Load(StartupPath + @"\TestConfig\" + fileName);
            var docRoot = doc.DocumentElement;
            var nodeValue = string.Empty;
            if (docRoot != null)
            {
                var selectSingleNode = docRoot.SelectSingleNode(nodeXPath);
                if (selectSingleNode != null)
                {
                    nodeValue = selectSingleNode.InnerXml;
                }
                else
                    throw new AssertFailedException("Failed to find node " + nodeXPath);
            }
            else
                throw new AssertFailedException("Failed to load xml");
            return nodeValue;
        }

        public string GetTransactionUrl(string dcName)
        {
            var url = string.Empty;
            if (dcName.ToLower().Contains("dc1"))
                url = DC1URL;
            if (dcName.ToLower().Contains("dc2"))
                url = DC2URL;
            return url;
        }
        
        public string GetRequestData(string TransactionType, string TenderType, string EntryMode)
        {
            string data="";
            var doc = new XmlDocument();
            doc.Load(StartupPath + @"\TestConfig\TransactionTemplates.xml");
            XmlNodeList Nodes = doc.SelectNodes("/Templates/TransactionType");
            foreach(XmlNode x in Nodes)
            {
                if(x.Attributes[0].Value.ToLower().Equals(TransactionType.ToLower()))
                {
                    foreach(XmlNode y in x.ChildNodes)
                    {
                        if (y.Attributes[0].Value.ToLower().Equals(TenderType.ToLower()))
                        {
                            foreach(XmlNode z in y.ChildNodes)
                            {
                                if(z.Attributes[0].Value.ToLower().Equals(EntryMode.ToLower()))
                                {
                                    data = z.InnerXml;
                                    break;

                                }                              

                            }
                            
                        }

                    }
                    
                }
            }
            if (string.IsNullOrEmpty(data))
                throw new AssertFailedException("Unable to Fetch XML. Please check Transaction Templates for neccesary Transaction/Tender/Entrymode types");
            return data;
        }

        public string GetTransId(string UserId, string Itr)
        {
            string str3 = string.Concat(UserId, Itr);
            string transid = str3.PadLeft(18, '0');
            return transid;

        }

        public string GetTransId()
        {
            Random rn = new Random();
            int r1 = rn.Next(111111111, 555555555);
            int r2 = rn.Next(555555556, 999999999);
            string r12 = string.Concat(r1.ToString(), r2.ToString());

            return r12;
        }

        public string GetIndType(string Indtype)
        {

            switch (Indtype.ToLower())
            {
                case "ecom":
                    return "ECOMMERCE";


                case "retail":
                    return "RETAIL";


                case "hsp":
                    return "RESTAURANT";

                case "moto":
                    return "MOTO";

                default:
                    return "RETAIL";


            }
        }
        
        public string GetOriginField(string Orfld)
            {

                switch (Orfld.ToLower())
                {
                    case "recurring":
                        return "RECURRING";

                    case "mo":
                        return "MAIL ORDER";

                    case "to":
                        return "PHONE ORDER";

                    case "retail":
                        return "POS";

                    case "ecom":
                        return "INTERNET";

                default:
                        return "";


                }
            }

        public string GetCardData(string Card_Type, string TenderType, string EntryMode)
        {
            string cdata = "";
            var doc = new XmlDocument();
            doc.Load(StartupPath + @"\TestData\CardData.xml");
            XmlNodeList Nodes = doc.SelectNodes("/Cardbrands/CardType");
            foreach (XmlNode x in Nodes)
            {
                if (x.Attributes[0].Value.ToLower().Equals(Card_Type.ToLower()))
                {
                    foreach (XmlNode y in x.ChildNodes)
                    {
                        if (y.Attributes[0].Value.ToLower().Equals(TenderType.ToLower()))
                        {
                            foreach (XmlNode z in y.ChildNodes)
                            {
                                if (z.Attributes[0].Value.ToLower().Equals(EntryMode.ToLower()))
                                {
                                    cdata = z.InnerXml;
                                    break;

                                }

                            }

                        }

                    }

                }
            }
            //if (string.IsNullOrEmpty(cdata))
                //throw new AssertFailedException("Unable to Fetch XML. Please check Transaction Templates for neccesary Transaction/Tender/Entrymode types");
            return cdata;
        }

    }
}
